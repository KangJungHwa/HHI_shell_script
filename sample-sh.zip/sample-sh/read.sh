#!/bin/sh

echo -n "Enter your ID: "
read id   #(1)

echo "Now your ID is $id"   #(2)
