#!/bin/sh

tar cvf archive.tar --exclude ".svn" myapp 
