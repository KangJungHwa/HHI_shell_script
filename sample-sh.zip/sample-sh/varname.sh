#!/bin/sh

today="20131106"
wc -l ${today}_log
